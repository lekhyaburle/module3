package com.cg.staticdb;
import java.util.HashMap;

import com.cg.bean.Product;
public class ProductDB {

	
		static HashMap<Integer, Product> productIdMap = getproductIdMap();
		
		static {
			if (productIdMap == null) {
				productIdMap = new HashMap<Integer, Product>();
				Product product1 = new Product(1, "Abc", 100);
				Product product2 = new Product(4, "Pqr", 200);
				Product product3 = new Product(3, "Xyz", 800);
				Product product4 = new Product(2, "Qwerty", 700);

				productIdMap.put(1, product1);			
				productIdMap.put(2, product2);
				productIdMap.put(3, product3);
				productIdMap.put(4, product4);
			}

		}
		/**
		 * This is a getter method of HashMap
		 * @return HashMap<Integer, product>
		 */
		public static HashMap<Integer, Product> getproductIdMap() {
			return productIdMap;
		}

}

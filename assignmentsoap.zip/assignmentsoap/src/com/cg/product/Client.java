package com.cg.product;

import java.net.URL;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.cg.service.ProductServer;

public class Client {
	public static void main(String[] args) throws Exception {
		
		URL url = new URL("http://localhost:9876/ps?wsdl");
		
		QName qname = new QName("http://service.cg.com/",
				"ProductserviceService");
		Service service = Service.create(url, qname);
		ProductServer endPointIntf = service.getPort(ProductServer.class);

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Product Id");
		int number1 = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Price is::\t"
				+ endPointIntf.getProductPrice(number1));
		scanner.close();
	}

}

package com.cg.dao;

import java.util.HashMap;

import com.cg.bean.Product;
import com.cg.staticdb.ProductDB;

public class ProductDao {
	static HashMap<Integer, Product> productIdMap = ProductDB.getproductIdMap();
	public float getProductPrice(int productId){		
			Product product = productIdMap.get(productId);
			return product.getProductPrice();
	}
}

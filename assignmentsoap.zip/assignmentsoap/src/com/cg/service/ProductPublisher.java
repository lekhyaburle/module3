package com.cg.service;

import javax.xml.ws.Endpoint;

public class ProductPublisher {
	public static void main(String[ ] args) {
	      // 1st argument is the publication URL
	      // 2nd argument is an SIB instance//SIB=Service Implementation Bean
	      Endpoint.publish("http://127.0.0.1:9876/ps", new Productservice());
	      System.out.println("Web service publish successfully");
	      System.out.println("press CTRL+C to terminate the server");
	    }
}

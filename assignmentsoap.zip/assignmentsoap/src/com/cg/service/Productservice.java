package com.cg.service;

import javax.jws.WebService;

import com.cg.dao.ProductDao;

@WebService(endpointInterface ="com.cg.service.ProductServer")
public class Productservice implements ProductServer{


	public float getProductPrice(int productId){
		ProductDao productDao=new ProductDao();
		return productDao.getProductPrice(productId);
	}
}
